$(document).ready(function(){
  
     $('.btn').waypoint(function(direction) {
        $('.btn').addClass('animated pulse');
    }
};